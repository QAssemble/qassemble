Module Dyson
  use Common  
  implicit None

  private
  ! public: Dyson

  ! interface Dyson
!    module procedure &
  public :: &
    FLatDyn, & ! Fermion, Lattice, dynamic
    FLocDyn, & ! Fermion, local, dynamic
    BLatDyn, & ! Boson, lattice, dynamic
    BLocDyn, & ! Boson, local, dynamic
    FLatStc, & ! Fermion, lattice, static
    FLocStc, &
    BLatStc, &
    BLocStc

  ! end interface Dyson

contains

  subroutine FLocStc(norb,ns,ffin,sig,ffout)
    
    ! use Common
    implicit none
    integer, intent(in) :: norb, ns
    complex*16,intent(in) :: ffin(norb,norb,ns), sig(norb,norb,ns)
    complex*16,intent(out) :: ffout(norb,norb,ns)
    
    integer :: is,iorb
    complex*16 :: tempmat1(norb,norb), tempmat2(norb,norb)
    
    ffout=0.0d0
    
    do is=1, ns
      tempmat1=0.0d0
      tempmat2=0.0d0
      call zgemm('n','n',norb,norb,norb,(-1.d0,0.d0), &
        sig(1,1,is),norb,ffin(1,1,is),norb, &
        (0.d0,0.d0),tempmat1,norb)
      do iorb=1, norb
        tempmat1(iorb,iorb)=tempmat1(iorb,iorb)+1.0d0
      enddo
      call dcmplx_matinv(tempmat1,tempmat2,norb,norb)
      call zgemm('n','n',norb,norb,norb,(1.d0,0.d0), &
        ffin(1,1,is),norb,tempmat2,norb, &
        (0.d0,0.d0),ffout(1,1,is),norb)          
    end do
  end subroutine FLocStc


  subroutine FLatStc(norb,ns,nk,ffin,sig,ffout)

    implicit none
    integer, intent(in) :: norb, nk,ns
    complex*16,intent(in) :: ffin(norb,norb,ns,nk), sig(norb,norb,ns,nk)
    complex*16,intent(out) :: ffout(norb,norb,ns,nk)

    integer :: ik

    ffout=0.0d0
    do ik=1, nk
      call FLocStc(norb,ns,ffin(:,:,:,ik),sig(:,:,:,ik),ffout(:,:,:,ik))
    enddo
      
  end subroutine FLatStc


  subroutine FLocDyn(norb,ns,nf,ffin,sig,ffout)
    

    implicit none
    integer, intent(in) :: norb, ns,nf
    complex*16,intent(in) :: ffin(norb,norb,ns,0:(nf-1)), sig(norb,norb,ns,0:(nf-1))
    complex*16,intent(out) :: ffout(norb,norb,ns,0:(nf-1))
    
    integer :: ifreq
    
    ffout=0.0d0
    do ifreq=0, nf-1
      call FLocStc(norb,ns,ffin(:,:,:,ifreq),sig(:,:,:,ifreq),ffout(:,:,:,ifreq))
    enddo
    
  end subroutine FLocDyn

  subroutine FLatDyn(norb,ns,nk,nf,ffin,sig,ffout)

    implicit none
    integer, intent(in) :: norb, nk,ns,nf
    complex*16,intent(in) :: ffin(norb,norb,ns,nk,0:(nf-1)), sig(norb,norb,ns,nk,0:(nf-1))
    complex*16,intent(out) :: ffout(norb,norb,ns,nk,0:(nf-1))
    
    integer :: ifreq
    ! complex*16 :: ffin_sub(norb,norb,ns,nk),sig_sub(norb,norb,ns,nk), &
    !   ffout_sub(norb,norb,ns,nk), ffout_temp(norb,norb,ns,nk,0:(nf-1))
    
    ffout=0.0d0
    do ifreq=0, nf-1
      call FLatStc(norb,ns,nk,ffin(:,:,:,:,ifreq),sig(:,:,:,:,ifreq),ffout(:,:,:,:,ifreq))
    enddo
  end subroutine FLatDyn
  
  
  subroutine BLocStc(norb,ns,ffin,sig,ffout)
    implicit none
    integer, intent(in) :: norb,ns
    complex*16,intent(in) :: ffin(norb,norb,ns,ns), sig(norb,norb,ns,ns)
    complex*16,intent(out) :: ffout(norb,norb,ns,ns)

    integer :: iorb,jorb,is,js,ndim
    integer*8 :: ind1, ind2,nn1(2),nn2(2)
    complex*16 :: tempmat1(norb*ns,norb*ns), tempmat2(norb*ns,norb*ns),sigtemp(norb*ns,norb*ns),ffintemp(norb*ns,norb*ns)

    ndim=norb*ns
    ffout=0.0d0
    sigtemp=0.0d0
    ffintemp=0.0d0
    do iorb=1, norb
      do is=1, ns
        nn1=(/iorb,is/)
        call indexing(ndim,2,(/norb,ns/),1,ind1,nn1)
        do jorb=1, norb        
          do js=1, ns
            nn2=(/jorb,js/)              
            call indexing(ndim,2,(/norb,ns/),1,ind2,nn2)
            sigtemp(ind1,ind2)=sig(iorb,jorb,is,js)
            ffintemp(ind1,ind2)=ffin(iorb,jorb,is,js)
          enddo
        enddo
      enddo
    enddo
    call zgemm('n','n',ndim,ndim,ndim,(-1.d0,0.d0), &
      sigtemp,ndim,ffintemp,ndim, &
      (0.d0,0.d0),tempmat1,ndim)
    
    do iorb=1, ndim
      tempmat1(iorb,iorb)=tempmat1(iorb,iorb)+1.0d0
    enddo
    call dcmplx_matinv(tempmat1,tempmat2,ndim,ndim)
    call zgemm('n','n',ndim,ndim,ndim,(1.d0,0.d0), &
      ffintemp,ndim,tempmat2,ndim, &
      (0.d0,0.d0),tempmat1,ndim)        
    do iorb=1, norb
      do is=1, ns
        nn1=(/iorb,is/)
        call indexing(ndim,2,(/norb,ns/),1,ind1,nn1)
        do jorb=1, norb        
          do js=1, ns
            nn2=(/jorb,js/)              
            call indexing(ndim,2,(/norb,ns/),1,ind2,nn2)
            ffout(iorb,jorb,is,js)=tempmat1(ind1,ind2)
          enddo
        enddo
      enddo
    enddo
  end subroutine BLocStc

  subroutine BLocDyn(norb,ns,nf,ffin,sig,ffout)
    implicit none
    integer, intent(in) :: norb,ns,nf
    complex*16,intent(in) :: ffin(norb,norb,ns,ns,0:(nf-1)), sig(norb,norb,ns,ns,0:(nf-1))
    complex*16,intent(out) :: ffout(norb,norb,ns,ns,0:(nf-1))
    
    integer :: ifreq
    
    ffout=0.0d0
    do ifreq=0, nf-1
      call BLocStc(norb,ns,ffin(:,:,:,:,ifreq),sig(:,:,:,:,ifreq),ffout(:,:,:,:,ifreq))
    enddo
    
  end subroutine BLocDyn

  
  subroutine BLatStc(norb,ns,nk,ffin,sig,ffout)
    implicit none
    integer, intent(in) :: norb,ns,nk
    complex*16,intent(in) :: ffin(norb,norb,ns,ns,nk), sig(norb,norb,ns,ns,nk)
    complex*16,intent(out) :: ffout(norb,norb,ns,ns,nk)

    integer :: ik
    
    ffout=0.0d0
    do ik=1, nk
      call BLocStc(norb,ns,ffin(:,:,:,:,ik),sig(:,:,:,:,ik),ffout(:,:,:,:,ik))
    enddo
    
  end subroutine BLatStc

  subroutine BLatDyn(norb,ns,nk,nf,ffin,sig,ffout)
    implicit none
    integer, intent(in) :: norb,ns,nk,nf
    complex*16,intent(in) :: ffin(norb,norb,ns,ns,nk,0:(nf-1)), sig(norb,norb,ns,ns,nk,0:(nf-1))
    complex*16,intent(out) :: ffout(norb,norb,ns,ns,nk,0:(nf-1))

    integer :: ifreq
    
    ffout=0.0d0
    do ifreq=0, nf-1
      call BLatStc(norb,ns,nk,ffin(:,:,:,:,:,ifreq),sig(:,:,:,:,:,ifreq),ffout(:,:,:,:,:,ifreq))
    enddo
    
    
  end subroutine BLatDyn
  

end Module Dyson
